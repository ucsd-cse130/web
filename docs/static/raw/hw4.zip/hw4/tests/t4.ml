let z1 = 4 in
let z = 3 in
let y = 2 in
let x = 1 in
let z1 = 0 in
if (x = 0) then y else p 
